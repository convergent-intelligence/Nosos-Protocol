# Substrate

The substrate is the ground reality of the system:
- invariants and constants
- state surface and schemas
- anomalies (things that break assumptions)
