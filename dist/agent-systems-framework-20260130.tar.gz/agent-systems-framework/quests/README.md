# Quests

Active work packages live here.

Use `quests/quest-template/` as a starting point.
