# Quest Origin

Why does this quest exist?

## Call

What triggers action now?

## Success

How will we verify completion?
