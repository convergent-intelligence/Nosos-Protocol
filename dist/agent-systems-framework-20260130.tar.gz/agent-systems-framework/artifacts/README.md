# Artifacts

Completed outputs are stored here. Prefer durable, reusable artifacts.
