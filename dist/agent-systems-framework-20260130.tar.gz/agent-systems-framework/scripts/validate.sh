#!/usr/bin/env bash
set -euo pipefail

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

required_files=(
  "${root_dir}/README.md"
  "${root_dir}/STATUS.md"
  "${root_dir}/PHASE-0.md"
  "${root_dir}/docs/system-brief.md"
  "${root_dir}/.bridges/protocols/signal-format.yaml"
  "${root_dir}/tools/plan-registry/plans.yaml"
  "${root_dir}/tools/state-tracker/state.yaml"
  "${root_dir}/tools/dependency-graph/graph.yaml"
  "${root_dir}/scripts/autofile"
  "${root_dir}/scripts/build-distro.sh"
  "${root_dir}/scripts/verify-distro.sh"
  "${root_dir}/scripts/health.sh"
  "${root_dir}/scripts/backup.sh"
  "${root_dir}/scripts/orchestrate"
  "${root_dir}/scripts/signal"
  "${root_dir}/tools/autofile/autofile.py"
  "${root_dir}/tools/autofile/README.md"
  "${root_dir}/tools/orchestrator/orchestrator.py"
  "${root_dir}/tools/orchestrator/README.md"
  "${root_dir}/tools/signal/signal.py"
  "${root_dir}/tools/signal/README.md"
  "${root_dir}/scripts/work"
  "${root_dir}/tools/work/work.py"
  "${root_dir}/tools/work/README.md"
  "${root_dir}/docs/tracking.md"
  "${root_dir}/docs/deploy/ionos-iso.md"
  "${root_dir}/docs/deploy/iso-build.md"
  "${root_dir}/docs/decisions/0002-iso-build-approach.md"
  "${root_dir}/docs/templates/bug.md"
  "${root_dir}/docs/templates/issue.md"
  "${root_dir}/docs/templates/dead-end.md"
  "${root_dir}/docs/templates/stub.md"
  "${root_dir}/scripts/build-iso.sh"
  "${root_dir}/docs/context-protocol.md"
  "${root_dir}/docs/templates/context-capsule.md"
  "${root_dir}/scripts/context"
  "${root_dir}/tools/context/context.py"
  "${root_dir}/tools/context/README.md"
)

missing=0
for f in "${required_files[@]}"; do
  if [[ ! -f "${f}" ]]; then
    printf "missing: %s\n" "${f}" >&2
    missing=1
  fi
done

if [[ "${missing}" -ne 0 ]]; then
  exit 1
fi

printf "ok: scaffold validates (%s)\n" "${root_dir}"
