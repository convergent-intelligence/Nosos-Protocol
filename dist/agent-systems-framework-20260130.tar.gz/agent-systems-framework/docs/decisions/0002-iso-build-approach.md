# Decision 0002: ISO Build Approach

Date: 2026-01-30
Status: proposed

## Context

We want to share a real server image that boots into a ready-to-run Agent Systems Framework environment. The target provider is IONOS.

## Decision

Pick one approach:

1) Installer ISO with automated install (recommended)
- deterministic, reproducible installs
- easier to keep clean (no baked-in runtime state)

2) Live ISO
- better for demos
- tends to accumulate state and requires more careful hardening

## Consequences

- Determines tooling (preseed/autoinstall vs live-build)
- Determines where first-boot config runs

## Alternatives Considered

- Distribute a VM image (qcow2/raw) instead of an ISO
- Use cloud-init images instead of ISO upload
