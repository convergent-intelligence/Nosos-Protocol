# System Brief (Draft)

## One Sentence

<What is this system, in one sentence?>

## Users

- <primary user>
- <secondary user>

## Non-Goals

- <what this is explicitly not>

## Interfaces

- Input: <API/CLI/files/events>
- Output: <API/CLI/files/events>

## Data

- What data exists?
- What data is sensitive?
- Where is the source of truth?

## Dependencies

- External systems:
- Internal modules:

## Risks

- Security:
- Reliability:
- Cost:

## Success

- What does “healthy” look like?
- What does “done” look like?
