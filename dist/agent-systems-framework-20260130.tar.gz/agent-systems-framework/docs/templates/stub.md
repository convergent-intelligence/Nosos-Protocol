# Stub: <title>

ID: <work id>
Date: 2026-01-30

## Thought

<incomplete idea or hypothesis>

## Why It Matters

<impact if true>

## What Would Confirm/Refute

- <test>

## Next Action

<smallest next step>
