# Bug: <title>

ID: <work id>
Date: 2026-01-30

## Symptom

<What is wrong?>

## Expected

<What should happen?>

## Actual

<What actually happens?>

## Repro

```bash
<commands>
```

## Scope

- Users impacted:
- Severity:

## Suspected Cause

<best hypothesis>

## Fix Plan

<steps>

## Evidence

- <links/paths>
