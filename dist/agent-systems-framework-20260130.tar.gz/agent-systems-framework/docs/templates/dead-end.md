# Dead End: <title>

ID: <work id>
Date: 2026-01-30

## What We Tried

<short narrative>

## Why It Failed

<root cause>

## Signals / Evidence

- <logs/paths>

## Do Instead

<recommended alternative>

## Guardrail

<how to prevent repeating this>
