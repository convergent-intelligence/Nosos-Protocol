# Issue: <title>

ID: <work id>
Date: 2026-01-30

## Problem

<What is the problem?>

## Constraints

- <constraint>

## Options

- Option A:
- Option B:

## Decision / Next

<What we will do next>
