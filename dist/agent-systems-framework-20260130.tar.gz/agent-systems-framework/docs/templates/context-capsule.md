# Context Capsule: <title>

Work ID: <work id>
Generated: 2026-01-30

## Objective

<one paragraph>

## Boundaries

In scope:
- <item>

Out of scope:
- <item>

## Invariants

- <invariant>

## Touch Points

Files:
- <path>

Commands:

```bash
./scripts/validate.sh
```

## Current State

- Health:
- Recent signals:

## Drift Guards

- Do not:
- Stop when:
