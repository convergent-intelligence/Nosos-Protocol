# Agents (Optional)

This directory is for identities/roles/ownership, when a project benefits from explicit actors.
If you are not using an agent framing, you can treat this as "ownership" and "access" docs.
