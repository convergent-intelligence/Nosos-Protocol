# Tools

This directory hosts small, file-first tools that support the framework.
Phase 0 includes:
- plan registry
- state tracker
- dependency graph
