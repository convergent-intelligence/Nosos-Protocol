# Context Tool

Generates a context capsule for a work item and links it from the plan registry.

Usage:

```bash
./scripts/context make P0-001
./scripts/context make ISSUE-001
```

Output:
- `artifacts/contexts/<id>_<slug>.md`
