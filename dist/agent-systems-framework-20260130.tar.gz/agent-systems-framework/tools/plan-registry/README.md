# Plan Registry

Purpose: store planned work items in a simple, searchable format.

Files:
- `schema.yaml` expected structure
- `plans.yaml` current work items
