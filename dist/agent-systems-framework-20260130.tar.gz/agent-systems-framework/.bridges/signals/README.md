# Signals

Signals are structured coordination messages.

This folder is the default drop point for:
- proclamations
- missives
- council calls

Schema reference:
- `.bridges/protocols/signal-format.yaml`

Tool:
- `./scripts/signal`
