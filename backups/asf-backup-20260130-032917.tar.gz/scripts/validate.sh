#!/usr/bin/env bash
set -euo pipefail

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

required_files=(
  "${root_dir}/README.md"
  "${root_dir}/STATUS.md"
  "${root_dir}/PHASE-0.md"
  "${root_dir}/docs/system-brief.md"
  "${root_dir}/.bridges/protocols/signal-format.yaml"
  "${root_dir}/tools/plan-registry/plans.yaml"
  "${root_dir}/tools/state-tracker/state.yaml"
  "${root_dir}/tools/dependency-graph/graph.yaml"
  "${root_dir}/scripts/autofile"
  "${root_dir}/scripts/build-distro.sh"
  "${root_dir}/scripts/verify-distro.sh"
  "${root_dir}/scripts/health.sh"
  "${root_dir}/scripts/backup.sh"
  "${root_dir}/tools/autofile/autofile.py"
  "${root_dir}/tools/autofile/README.md"
)

missing=0
for f in "${required_files[@]}"; do
  if [[ ! -f "${f}" ]]; then
    printf "missing: %s\n" "${f}" >&2
    missing=1
  fi
done

if [[ "${missing}" -ne 0 ]]; then
  exit 1
fi

printf "ok: scaffold validates (%s)\n" "${root_dir}"
