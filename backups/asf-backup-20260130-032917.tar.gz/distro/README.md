# Distro

The distro is the shippable bundle of this scaffold.

Key files:
- `distro/MANIFEST.yaml` what should ship
- `distro/BUILD.md` how to build and verify
