# Index

Machine-facing indexes live here.

- `autofile.sqlite` is the primary index for blobs, units, and attachment links.
- `audit.jsonl` is an append-only activity log.
