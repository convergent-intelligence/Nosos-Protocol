# Decision 0001: <title>

Date: 2026-01-30
Status: proposed | accepted | superseded

## Context

<What problem are we solving?>

## Decision

<What did we choose?>

## Consequences

<What becomes easier/harder?>

## Alternatives Considered

- <alt 1>
- <alt 2>
