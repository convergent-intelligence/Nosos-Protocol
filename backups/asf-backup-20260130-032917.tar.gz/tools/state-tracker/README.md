# State Tracker

Purpose: track the current state of the system as a small, structured file.

Files:
- `schema.yaml` expected structure
- `state.yaml` current state snapshot
