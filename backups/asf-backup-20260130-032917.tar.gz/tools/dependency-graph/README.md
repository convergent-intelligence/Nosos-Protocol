# Dependency Graph

Purpose: record components and their dependencies early, before the system ossifies.

Files:
- `schema.yaml` expected structure
- `graph.yaml` current graph
