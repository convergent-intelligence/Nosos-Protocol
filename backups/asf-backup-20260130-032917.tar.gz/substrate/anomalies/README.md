# Anomalies

Record observations that don't fit current assumptions.
Prefer short, timestamped notes.
